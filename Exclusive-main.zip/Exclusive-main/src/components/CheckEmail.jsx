function CheckEmail() {
  return (
    <div className="py-[140px] flex flex-col items-center justify-center capitalize gap-4">
      <h1 className="text-4xl font-bold ">Please Check Your Email 📩</h1>
    </div>
  );
}

export default CheckEmail;
