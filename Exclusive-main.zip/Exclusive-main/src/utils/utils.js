export function isResponsive() {
  return window.innerWidth <= 1023;
}
